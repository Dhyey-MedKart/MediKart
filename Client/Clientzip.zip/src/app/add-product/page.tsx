import AddProduct from '@/components/AddProduct'
import React from 'react'

function page() {
  return (
    <AddProduct />
  )
}

export default page