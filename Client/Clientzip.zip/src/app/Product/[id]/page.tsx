import React from 'react'
import ProductPage from '@/components/Product'
function page() {
  return (
    <div>
      <ProductPage />
    </div>
  )
}

export default page
