import React from 'react'
import Dashboard from '../../components/Dashboard'

function page() {
  return (
    <Dashboard/>
  )
}

export default page