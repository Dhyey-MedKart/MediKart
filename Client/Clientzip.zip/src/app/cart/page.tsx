import Cart from '@/components/Cart'
import React from 'react'

function page() {
  return (
    <Cart/>
  )
}

export default page