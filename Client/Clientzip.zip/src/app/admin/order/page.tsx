import React from 'react'
import AdminOrderPage from '../../../components/Admin/Orders'

function page() {
  return (
    <AdminOrderPage/>
  )
}

export default page