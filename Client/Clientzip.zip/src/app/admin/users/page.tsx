import AllUsers from "../../../components/Admin/users";

import React from 'react'

function page() {
  return (
    <div>
      <AllUsers/>
    </div>
  )
}

export default page
