import React from 'react'
import EditProduct from '../../../../components/EditProduct'

function page() {
  return (
    <EditProduct/>
  )
}

export default page